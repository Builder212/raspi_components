class ResistorError(Exception):
    """
    Raised when there is an error while working with the VariableResistor class.
    """
    def __init__(self):
        pass
