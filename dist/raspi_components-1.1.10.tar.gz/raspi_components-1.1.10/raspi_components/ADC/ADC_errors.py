class ADCError(Exception):
    """
    Raised when there is an error while working with the ADC class.
    """
    def __init__(self):
        pass
