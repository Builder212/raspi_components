class ButtonError(Exception):
    """
    Raised when there is an error while working with the Button class.
    """
    def __init__(self):
        pass
